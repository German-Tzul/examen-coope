@extends('base')

@section('contenido')
<div class="container">
    <div class="row">
      <div class="col-md-4">
        <h1>Nota Detalle</h1>
        <hr />
        <h4>Id: {{ $persona->id }}</h4>
        <h4>Cui: {{ $persona->cui }}</h4>
        <h4>Nombre: {{ $persona->nombre }}</h4>
      </div>
      <div class="col-md-6">
        <form method="POST" action="{{route('prospecto.store')}}">
            @csrf
            <div class="mb-3">
                <label for="producto_id" class="form-label">Productos</label>
            <select name="producto_id" class="form-select">
                @foreach ($producto as $item)
                    <option value="{{$item->id}}">{{$item->nombre}}</option>
                @endforeach
            </select>
            </div>
            <div class="mb-3">
                <label for="comentario" class="form-label">Comentario</label>
                <input id="comentario" type="text" name="comentario" class="@error('comentario') is-invalid @enderror form-control">  
                @error('comentario')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror
            </div>
            <div class="mb-3">
                {{-- <label for="persona_id" class="form-label">Cui Persona</label> --}}
                <input id="persona_id" type="hidden" 
                       value="{{$persona->id}}" name="persona_id" class="@error('persona_id') is-invalid @enderror form-control">  
                @error('persona_id')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror
            </div> 

            
            @if (session('mensaje'))
                <div class="alert alert-success">
                    {{ session('mensaje') }}
                </div>
            @endif
            <button type="submit" class="btn btn-primary">Guardar Informacion</button>           
        </form>
      </div>
      <div class="col-md-2">
        Column
      </div>
    </div>
  </div>

@endsection