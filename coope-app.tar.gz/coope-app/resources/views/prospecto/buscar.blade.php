@extends('base')

@section('contenido')
<div class="container">
    <div class="row">
      <div class="col-md-3">
        
      </div>
      <div class="col-md-6">
        <h3>Ingresa el codigo del cliente</h3>
        <form method="POST" action="{{route('buscar_persona')}}">
            @csrf
           
            <div class="mb-3">
                <label for="buscar" class="form-label">Codigo</label>
                <input id="buscar" type="text" name="buscar" class="@error('buscar') is-invalid @enderror form-control">  
                @error('buscar')
                <div class="alert alert-danger">{{ $message }}</div>
                @enderror
            </div>
            <button type="submit" class="btn btn-primary">Buscar Informacion</button>           
        </form>
      </div>
      <div class="col-md-3">
      </div>
    </div>
  </div>

@endsection