@extends('base')

@section('contenido')
<div class="container">
    <div class="row">
      <div class="col-md-3">
      </div>
      <div class="col-md-6">
        <form method="POST" action="{{route('producto.store')}}">
            @csrf
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre Producto</label>
                <input id="nombre" type="text" name="nombre" class="@error('nombre') is-invalid @enderror form-control">  
                @error('nombre')
                <div class="alert alert-danger">{{ $message }}</div>
            @enderror
            </div>
            @if (session('mensaje'))
                <div class="alert alert-success">
                    {{ session('mensaje') }}
                </div>
            @endif
            <button type="submit" class="btn btn-primary">Guardar Informacion</button>           
        </form>
      </div>
      <div class="col-md-3">
      </div>
    </div>
  </div>

@endsection