@extends('base')

@section('contenido')
<div class="container">
    <div class="row">
      <div class="col-md-3">
        Column
      </div>
      <div class="col-md-6">
        <form method="POST" action="{{route('persona.store')}}">
            @csrf    
            <div class="mb-3">
                <label for="cui" class="form-label">Cui</label>
                <input id="cui" type="text" name="cui" class="@error('cui') is-invalid @enderror form-control">  
                @error('cui')
                <div class="alert alert-danger">{{ $message }}</div>
            @enderror
            </div>
            <div class="mb-3">
                <label for="nombre" class="form-label">Nombre</label>
                <input id="nombre" type="text" name="nombre" class="@error('nombre') is-invalid @enderror form-control">  
                @error('nombre')
                <div class="alert alert-danger">{{ $message }}</div>
            @enderror
            </div>
            <div class="mb-3">
                <label for="telefono" class="form-label">Telefono</label>
                <input id="telefono" type="text" name="telefono" class="@error('telefono') is-invalid @enderror form-control">  
                @error('telefono')
                <div class="alert alert-danger">{{ $message }}</div>
            @enderror
            </div>
            
            @if (session('mensaje'))
                <div class="alert alert-success">
                    {{ session('mensaje') }}
                </div>
            @endif
            <button type="submit" class="btn btn-primary">Guardar Informacion</button>           
        </form>
      </div>
      <div class="col-md-3">
        Column
      </div>
    </div>
  </div>

@endsection