@extends('base')

@section('contenido')
<div class="container">
    <div class="row">
      <div class="col-md-3">
      </div>
      <div class="col-md-6">
        <table class="table">
            <thead>
              <tr>
                <th scope="col">id</th>
                <th scope="col">Cui</th>
                <th scope="col">Nombre</th>
              </tr>
            </thead>
            <tbody>
              @foreach ($persona as $item)
              <tr>
                <th scope="row">{{ $item->id }}</th>
                <td>{{ $item->cui }}</td>
                <td>{{ $item->nombre }}</td>
              </tr>
              @endforeach
            </tbody>
          </table>
      </div>
      <div class="col-md-3">
      </div>
    </div>
  </div>

@endsection