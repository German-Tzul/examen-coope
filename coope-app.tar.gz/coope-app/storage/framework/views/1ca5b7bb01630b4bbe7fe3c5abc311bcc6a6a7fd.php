<?php $__env->startSection('contenido'); ?>
<div class="container">
    <div class="row">
      <div class="col-md-4">
        <h1>Nota Detalle</h1>
        <hr />
        <h4>Id: <?php echo e($persona->id); ?></h4>
        <h4>Cui: <?php echo e($persona->cui); ?></h4>
        <h4>Nombre: <?php echo e($persona->nombre); ?></h4>
      </div>
      <div class="col-md-6">
        <form method="POST" action="<?php echo e(route('prospecto.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="producto_id" class="form-label">Productos</label>
            <select name="producto_id" class="form-select">
                <?php $__currentLoopData = $producto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            </div>
            <div class="mb-3">
                <label for="comentario" class="form-label">Comentario</label>
                <input id="comentario" type="text" name="comentario" class="<?php $__errorArgs = ['comentario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control">  
                <?php $__errorArgs = ['comentario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="mb-3">
                
                <input id="persona_id" type="hidden" 
                       value="<?php echo e($persona->id); ?>" name="persona_id" class="<?php $__errorArgs = ['persona_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control">  
                <?php $__errorArgs = ['persona_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div> 

            
            <?php if(session('mensaje')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('mensaje')); ?>

                </div>
            <?php endif; ?>
            <button type="submit" class="btn btn-primary">Guardar Informacion</button>           
        </form>
      </div>
      <div class="col-md-2">
        Column
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/prospecto/show.blade.php ENDPATH**/ ?>