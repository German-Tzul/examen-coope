<?php

use App\Http\Controllers\PersonaController;
use App\Http\Controllers\ProductoController;
use App\Http\Controllers\ProspectoController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get(
    '/persona/buscar',
    [ProspectoController::class, 'formulario_buscar_persona']
)->name('formulario_buscar_persona');



Route::post('/buscar',
[ProspectoController::class, 'buscar_persona']
)->name('buscar_persona');



Route::resources([
    'producto' => ProductoController::class,
    'persona' => PersonaController::class,
    'prospecto' => ProspectoController::class
]);
